
package vn.edu.khoa.grocery.model;
public class Product {
  private Integer id; private String sku; private String name; private Integer categoryId; private String unit; private double costPrice; private double salePrice; private int stock;
  public Product(){} public Product(Integer id,String sku,String name,Integer categoryId,String unit,double cost,double sale,int stock){ this.id=id; this.sku=sku; this.name=name; this.categoryId=categoryId; this.unit=unit; this.costPrice=cost; this.salePrice=sale; this.stock=stock; }
  public Integer getId(){return id;} public void setId(Integer v){id=v;} public String getSku(){return sku;} public void setSku(String v){sku=v;} public String getName(){return name;} public void setName(String v){name=v;}
  public Integer getCategoryId(){return categoryId;} public void setCategoryId(Integer v){categoryId=v;} public String getUnit(){return unit;} public void setUnit(String v){unit=v;}
  public double getCostPrice(){return costPrice;} public void setCostPrice(double v){costPrice=v;} public double getSalePrice(){return salePrice;} public void setSalePrice(double v){salePrice=v;} public int getStock(){return stock;} public void setStock(int v){stock=v;}
}
