package vn.edu.khoa.grocery.ui.panels;

import vn.edu.khoa.grocery.dao.CategoryDAO;
import vn.edu.khoa.grocery.model.Category;
import vn.edu.khoa.grocery.ui.events.AppEventBus;
import vn.edu.khoa.grocery.ui.events.AppEventType;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Quản lý Danh mục
 * - Thêm/xoá danh mục
 * - Reload bảng ngay sau thao tác
 * - Phát sự kiện CATEGORY_CHANGED để ProductPanel tự reload combobox
 */
public class CategoryPanel extends JPanel {

    private final CategoryDAO dao = new CategoryDAO();

    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"ID", "Tên danh mục"}, 0
    ) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };

    private final JTable table = new JTable(model);
    private final JTextField txtName = new JTextField(18);

    public CategoryPanel() {
        setLayout(new BorderLayout(10, 10));
        setOpaque(false);

        // ===== Header =====
        JLabel title = new JLabel("Danh mục");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 18f));
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.add(title, BorderLayout.WEST);
        add(header, BorderLayout.NORTH);

        // ===== Bảng =====
        table.setRowHeight(26);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // ===== Form + nút =====
        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        form.setOpaque(false);
        form.add(new JLabel("Tên:"));
        form.add(txtName);

        JButton btnAdd = new JButton("Thêm");
        JButton btnReload = new JButton("Tải lại");
        JButton btnDelete = new JButton("Xoá");
        form.add(btnAdd);
        form.add(btnReload);
        form.add(btnDelete);

        add(form, BorderLayout.SOUTH);

        // ===== Sự kiện =====
        btnAdd.addActionListener(e -> doAdd());
        btnDelete.addActionListener(e -> doDelete());
        btnReload.addActionListener(e -> load());

        // Load lần đầu
        load();
    }

    /** Tải dữ liệu danh mục vào bảng */
    private void load() {
        model.setRowCount(0);
        try {
            List<Category> list = dao.findAll();
            for (Category c : list) {
                model.addRow(new Object[]{c.getId(), c.getName()});
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** Thêm danh mục mới */
    private void doAdd() {
        String name = txtName.getText() == null ? "" : txtName.getText().trim();
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tên danh mục không được trống!");
            txtName.requestFocus();
            return;
        }
        try {
            Integer id = dao.insert(new Category(null, name));
            if (id != null) {
                load();                    // cập nhật bảng ngay
                txtName.setText("");       // dọn form
                txtName.requestFocus();    // focus lại để nhập tiếp
                // thông báo cho các panel khác (ProductPanel) biết danh mục đã thay đổi
                AppEventBus.get().publish(AppEventType.CATEGORY_CHANGED);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** Xoá danh mục đang chọn */
    private void doDelete() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Hãy chọn một dòng để xoá");
            return;
        }
        int id = (Integer) model.getValueAt(row, 0);
        String name = String.valueOf(model.getValueAt(row, 1));

        if (JOptionPane.showConfirmDialog(
                this,
                "Xoá danh mục \"" + name + "\"?",
                "Xác nhận",
                JOptionPane.YES_NO_OPTION
        ) != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            if (dao.delete(id)) {
                load(); // cập nhật bảng
                AppEventBus.get().publish(AppEventType.CATEGORY_CHANGED);
            }
        } catch (Exception ex) {
            // Nếu bị ràng buộc FK (đang có sản phẩm dùng danh mục này)
            JOptionPane.showMessageDialog(
                    this,
                    "Không thể xoá: danh mục đang được sử dụng bởi sản phẩm khác.\nChi tiết: " + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}
