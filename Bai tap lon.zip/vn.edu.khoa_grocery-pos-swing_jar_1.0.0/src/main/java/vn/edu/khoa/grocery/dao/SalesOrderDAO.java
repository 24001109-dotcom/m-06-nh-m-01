
package vn.edu.khoa.grocery.dao;
import vn.edu.khoa.grocery.config.DB; import vn.edu.khoa.grocery.model.SalesOrder; import java.sql.*; import java.util.*;
public class SalesOrderDAO implements CrudDAO<SalesOrder,Integer>{
  public Integer insert(SalesOrder o) throws Exception {
    String sql="INSERT INTO sales_orders(customer_id, order_date, total) VALUES(?,?,?)";
    try(Connection c=DB.getConnection(); PreparedStatement ps=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){
      if(o.getCustomerId()==null) ps.setNull(1, Types.INTEGER); else ps.setInt(1,o.getCustomerId());
      ps.setDate(2, java.sql.Date.valueOf(o.getOrderDate())); ps.setDouble(3,o.getTotal());
      ps.executeUpdate();
      try(ResultSet rs=ps.getGeneratedKeys()){ if(rs.next()) return rs.getInt(1); }
    }
    return null;
  }
  public boolean update(SalesOrder o) throws Exception {
    String sql="UPDATE sales_orders SET customer_id=?, order_date=?, total=? WHERE id=?";
    try(Connection c=DB.getConnection(); PreparedStatement ps=c.prepareStatement(sql)){
      if(o.getCustomerId()==null) ps.setNull(1, Types.INTEGER); else ps.setInt(1,o.getCustomerId());
      ps.setDate(2, java.sql.Date.valueOf(o.getOrderDate())); ps.setDouble(3,o.getTotal()); ps.setInt(4,o.getId());
      return ps.executeUpdate()>0;
    }
  }
  public boolean delete(Integer id) throws Exception {
    try(Connection c=DB.getConnection(); PreparedStatement ps=c.prepareStatement("DELETE FROM sales_orders WHERE id=?")){
      ps.setInt(1,id); return ps.executeUpdate()>0;
    }
  }
  public Optional<SalesOrder> findById(Integer id) throws Exception {
    try(Connection c=DB.getConnection(); PreparedStatement ps=c.prepareStatement("SELECT * FROM sales_orders WHERE id=?")){
      ps.setInt(1,id); try(ResultSet rs=ps.executeQuery()){ if(rs.next()) return Optional.of(map(rs)); }
    }
    return Optional.empty();
  }
  public List<SalesOrder> findAll() throws Exception {
    List<SalesOrder> list=new ArrayList<>();
    try(Connection c=DB.getConnection(); Statement st=c.createStatement(); ResultSet rs=st.executeQuery("SELECT * FROM sales_orders ORDER BY id DESC")){
      while(rs.next()) list.add(map(rs));
    }
    return list;
  }
  private SalesOrder map(ResultSet rs) throws SQLException {
    return new SalesOrder(rs.getInt("id"), (Integer)rs.getObject("customer_id"), rs.getDate("order_date").toLocalDate(), rs.getDouble("total"));
  }
}
