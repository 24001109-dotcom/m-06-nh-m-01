
package vn.edu.khoa.grocery.model;
public class Category { private Integer id; private String name;
  public Category(){} public Category(Integer id,String name){ this.id=id; this.name=name; }
  public Integer getId(){return id;} public void setId(Integer v){id=v;} public String getName(){return name;} public void setName(String v){name=v;}
}
