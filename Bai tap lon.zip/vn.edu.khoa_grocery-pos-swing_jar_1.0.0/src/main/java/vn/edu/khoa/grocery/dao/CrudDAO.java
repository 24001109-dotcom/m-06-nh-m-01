
package vn.edu.khoa.grocery.dao;
import java.util.*; public interface CrudDAO<T,K>{
  K insert(T t) throws Exception; boolean update(T t) throws Exception; boolean delete(K id) throws Exception;
  Optional<T> findById(K id) throws Exception; List<T> findAll() throws Exception;
}
