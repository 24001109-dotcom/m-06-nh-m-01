package vn.edu.khoa.grocery.ui.panels;

import vn.edu.khoa.grocery.dao.UserDAO;
import vn.edu.khoa.grocery.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Quản lý tài khoản người dùng (ADMIN/STAFF)
 * - Hiển thị danh sách user
 * - Thêm user mới (mật khẩu sẽ được hash BCrypt ở DAO)
 * - Đặt lại mật khẩu user
 * - Xóa user
 */
public class UserPanel extends JPanel {

    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"ID", "Username", "Họ tên", "Vai trò"}, 0
    ){
        @Override public boolean isCellEditable(int r, int c){ return false; }
    };

    private final JTable table = new JTable(model);
    private final JTextField txtUsername = new JTextField(16);
    private final JTextField txtFullname = new JTextField(18);
    private final JPasswordField txtPassword = new JPasswordField(16);
    private final JComboBox<String> cbRole = new JComboBox<>(new String[]{"ADMIN","STAFF"});

    private final UserDAO dao = new UserDAO();

    public UserPanel(){
        setLayout(new BorderLayout(10,10));

        // Tiêu đề
        JLabel title = new JLabel("Quản lý người dùng");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 16f));
        add(title, BorderLayout.NORTH);

        // Bảng
        table.setRowHeight(24);
        table.getTableHeader().setReorderingAllowed(false);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // Form thêm mới
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Thêm người dùng"));
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5,5,5,5);
        gc.anchor = GridBagConstraints.WEST;

        int row = 0;
        gc.gridx=0; gc.gridy=row; form.add(new JLabel("Username:"), gc);
        gc.gridx=1; form.add(txtUsername, gc);

        row++;
        gc.gridx=0; gc.gridy=row; form.add(new JLabel("Họ tên:"), gc);
        gc.gridx=1; form.add(txtFullname, gc);

        row++;
        gc.gridx=0; gc.gridy=row; form.add(new JLabel("Mật khẩu:"), gc);
        gc.gridx=1; form.add(txtPassword, gc);

        row++;
        gc.gridx=0; gc.gridy=row; form.add(new JLabel("Vai trò:"), gc);
        gc.gridx=1; form.add(cbRole, gc);

        JButton btnAdd = new JButton("Thêm");
        btnAdd.addActionListener(e -> doAddUser());

        JButton btnResetPass = new JButton("Đặt lại mật khẩu…");
        btnResetPass.addActionListener(e -> doResetPassword());

        JButton btnDelete = new JButton("Xóa");
        btnDelete.addActionListener(e -> doDeleteUser());

        JButton btnReload = new JButton("Tải lại");
        btnReload.addActionListener(e -> reload());

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actions.add(btnReload);
        actions.add(btnResetPass);
        actions.add(btnDelete);
        actions.add(btnAdd);

        JPanel south = new JPanel(new BorderLayout());
        south.add(form, BorderLayout.CENTER);
        south.add(actions, BorderLayout.SOUTH);

        add(south, BorderLayout.SOUTH);

        // Nạp dữ liệu
        reload();
    }

    private void reload(){
        model.setRowCount(0);
        try{
            List<User> list = dao.findAll();
            for (User u : list){
                model.addRow(new Object[]{ u.getId(), u.getUsername(), u.getFullName(), u.getRole() });
            }
        }catch (Exception ex){
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void doAddUser(){
        String username = txtUsername.getText().trim();
        String fullname = txtFullname.getText().trim();
        String password = new String(txtPassword.getPassword());
        String role = (String) cbRole.getSelectedItem();

        if (username.isEmpty() || password.isEmpty()){
            JOptionPane.showMessageDialog(this, "Username và mật khẩu không được để trống");
            return;
        }

        try{
            // Lưu ý: Ở UserDAO.insert(User), mật khẩu sẽ được hash BCrypt.
            User u = new User(null, username, password, fullname, role);
            boolean ok = dao.insert(u);
            if (ok){
                JOptionPane.showMessageDialog(this, "Đã thêm người dùng");
                txtUsername.setText("");
                txtFullname.setText("");
                txtPassword.setText("");
                cbRole.setSelectedIndex(0);
                reload();
            }else{
                JOptionPane.showMessageDialog(this, "Không thể thêm người dùng");
            }
        }catch (Exception ex){
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void doResetPassword(){
        int row = table.getSelectedRow();
        if (row < 0){
            JOptionPane.showMessageDialog(this, "Chọn một người dùng để đặt lại mật khẩu");
            return;
        }
        int id = (int) model.getValueAt(row, 0);
        String username = (String) model.getValueAt(row, 1);

        JPasswordField pf = new JPasswordField();
        int opt = JOptionPane.showConfirmDialog(this, pf,
                "Nhập mật khẩu mới cho: " + username, JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (opt != JOptionPane.OK_OPTION) return;

        String newPass = new String(pf.getPassword()).trim();
        if (newPass.isEmpty()){
            JOptionPane.showMessageDialog(this, "Mật khẩu mới không được để trống");
            return;
        }

        try{
            boolean ok = dao.setPassword(id, newPass); // DAO sẽ tự hash BCrypt
            if (ok){
                JOptionPane.showMessageDialog(this, "Đã đặt lại mật khẩu");
            }else{
                JOptionPane.showMessageDialog(this, "Không thể đặt lại mật khẩu");
            }
        }catch (Exception ex){
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void doDeleteUser(){
        int row = table.getSelectedRow();
        if (row < 0){
            JOptionPane.showMessageDialog(this, "Chọn người dùng cần xóa");
            return;
        }
        int id = (int) model.getValueAt(row, 0);
        String username = (String) model.getValueAt(row, 1);

        int cf = JOptionPane.showConfirmDialog(this,
                "Xóa tài khoản: " + username + " ?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (cf != JOptionPane.YES_OPTION) return;

        try{
            boolean ok = dao.delete(id);
            if (ok){
                JOptionPane.showMessageDialog(this, "Đã xóa");
                reload();
            }else{
                JOptionPane.showMessageDialog(this, "Không thể xóa");
            }
        }catch (Exception ex){
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }
}
