package vn.edu.khoa.grocery.dao;

import vn.edu.khoa.grocery.config.DB;
import vn.edu.khoa.grocery.model.Customer;

import java.sql.*;
import java.util.*;

public class CustomerDAO implements CrudDAO<Customer, Integer> {

    @Override
    public Integer insert(Customer s) throws Exception {
        String sql="INSERT INTO customers(name,phone,address) VALUES(?,?,?)";
        try(Connection c=DB.getConnection();
            PreparedStatement ps=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){
            ps.setString(1,s.getName());
            ps.setString(2,s.getPhone());
            ps.setString(3,s.getAddress());
            ps.executeUpdate();
            try(ResultSet rs=ps.getGeneratedKeys()){
                if(rs.next()) return rs.getInt(1);
            }
        }
        return null;
    }

    @Override
    public boolean update(Customer s) throws Exception {
        String sql="UPDATE customers SET name=?, phone=?, address=? WHERE id=?";
        try(Connection c=DB.getConnection();
            PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,s.getName());
            ps.setString(2,s.getPhone());
            ps.setString(3,s.getAddress());
            ps.setInt(4,s.getId());
            return ps.executeUpdate()>0;
        }
    }

    // Overload để nơi khác có thể gọi dao.delete(id) với id là int
    public boolean delete(int id) throws Exception {
        return delete(Integer.valueOf(id));
    }

    @Override
    public boolean delete(Integer id) throws Exception {
        try(Connection c=DB.getConnection();
            PreparedStatement ps=c.prepareStatement("DELETE FROM customers WHERE id=?")){
            ps.setInt(1,id);
            return ps.executeUpdate()>0;
        }
    }

    @Override
    public Optional<Customer> findById(Integer id) throws Exception {
        try(Connection c=DB.getConnection();
            PreparedStatement ps=c.prepareStatement("SELECT * FROM customers WHERE id=?")){
            ps.setInt(1,id);
            try(ResultSet rs=ps.executeQuery()){
                if(rs.next()) return Optional.of(map(rs));
            }
        }
        return Optional.empty();
    }

    @Override
    public List<Customer> findAll() throws Exception {
        List<Customer> list=new ArrayList<>();
        try(Connection c=DB.getConnection();
            Statement st=c.createStatement();
            ResultSet rs=st.executeQuery("SELECT * FROM customers ORDER BY id DESC")){
            while(rs.next()) list.add(map(rs));
        }
        return list;
    }

    private Customer map(ResultSet rs) throws SQLException {
        return new Customer(
                rs.getInt("id"),
                rs.getString("name"),
                rs.getString("phone"),
                rs.getString("address")
        );
    }

    // ====== Helpers cho luồng "Khách mua hàng" ====== //

    /** Kiểm tra tên khách đã tồn tại chưa */
    public static boolean existsByName(String name) throws Exception {
        String sql = "SELECT 1 FROM customers WHERE name=? LIMIT 1";
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }

    /** Thêm nhanh KH và trả về ID */
    public static int insertReturningId(String name, String phone, String address) throws Exception {
        String sql = "INSERT INTO customers(name, phone, address) VALUES (?,?,?)";
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, name);
            ps.setString(2, phone);
            ps.setString(3, address);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) { rs.next(); return rs.getInt(1); }
        }
    }

    /** Gợi ý tên không trùng */
    public static String suggestUniqueName(String base) throws Exception {
        String candidate = base;
        int tries = 0;
        while (existsByName(candidate) && tries < 50) {
            candidate = base + "_" + (1000 + new java.util.Random().nextInt(9000));
            tries++;
        }
        return candidate;
    }
}
