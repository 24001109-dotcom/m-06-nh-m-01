package vn.edu.khoa.grocery.ui.panels;

import vn.edu.khoa.grocery.config.DB;
import vn.edu.khoa.grocery.dao.ProductDAO;
import vn.edu.khoa.grocery.ui.theme.UiUtils;
import vn.edu.khoa.grocery.ui.events.*;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.*;
import java.text.NumberFormat;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class ProductPanel extends JPanel {

    static void reloadStaticIfAny() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"ID", "SKU", "Tên", "Danh mục", "Đơn vị", "Giá vốn", "Giá bán", "Tồn"}, 0
    ) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);

    private final JTextField txtSku = new JTextField(16);
    private final JTextField txtName = new JTextField(22);
    private final JComboBox<CategoryItem> cbCategory = new JComboBox<>();
    private final JTextField txtUnit = new JTextField(10);

    private final JFormattedTextField fCost =
            new JFormattedTextField(NumberFormat.getNumberInstance(new Locale("vi", "VN")));
    private final JFormattedTextField fPrice =
            new JFormattedTextField(NumberFormat.getNumberInstance(new Locale("vi", "VN")));

    private Integer currentId = null;

    public ProductPanel() {
        setOpaque(false);
        setLayout(new BorderLayout(10, 10));

        JLabel title = new JLabel("Sản phẩm");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 18f));
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.add(title, BorderLayout.WEST);
        add(header, BorderLayout.NORTH);

        UiUtils.styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(table), BorderLayout.CENTER);

        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override public void valueChanged(ListSelectionEvent e) {
                int r = table.getSelectedRow();
                if (r >= 0) {
                    currentId = (Integer) model.getValueAt(r, 0);
                    txtSku.setText(String.valueOf(model.getValueAt(r, 1)));
                    txtName.setText(String.valueOf(model.getValueAt(r, 2)));
                    selectCategoryByName(String.valueOf(model.getValueAt(r, 3)));
                    txtUnit.setText(String.valueOf(model.getValueAt(r, 4)));
                    fCost.setValue(toNumber(model.getValueAt(r, 5)));
                    fPrice.setValue(toNumber(model.getValueAt(r, 6)));
                }
            }
        });

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6,6,6,6);
        c.anchor = GridBagConstraints.WEST;

        int row = 0;
        c.gridx=0; c.gridy=row; form.add(new JLabel("SKU:"), c);
        c.gridx=1; form.add(txtSku, c);

        c.gridx=2; form.add(new JLabel("Tên:"), c);
        c.gridx=3; c.fill = GridBagConstraints.HORIZONTAL; c.weightx=1; form.add(txtName, c);
        c.fill = GridBagConstraints.NONE; c.weightx=0;

        row++;
        c.gridx=0; c.gridy=row; form.add(new JLabel("Danh mục:"), c);
        c.gridx=1; form.add(cbCategory, c);

        c.gridx=2; form.add(new JLabel("Đơn vị:"), c);
        c.gridx=3; form.add(txtUnit, c);

        row++;
        fCost.setColumns(10);
        fPrice.setColumns(10);
        c.gridx=0; c.gridy=row; form.add(new JLabel("Giá vốn:"), c);
        c.gridx=1; form.add(fCost, c);
        c.gridx=2; form.add(new JLabel("Giá bán:"), c);
        c.gridx=3; form.add(fPrice, c);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actions.setOpaque(false);
        JButton btnAdd = UiUtils.primaryButton("Thêm");
        JButton btnUpdate = UiUtils.primaryButton("Sửa");
        JButton btnDelete = UiUtils.dangerButton("Xoá");
        JButton btnClear = new JButton("Làm mới");
        actions.add(btnClear);
        actions.add(btnAdd);
        actions.add(btnUpdate);
        actions.add(btnDelete);

        JPanel south = new JPanel(new BorderLayout());
        south.setOpaque(false);
        south.add(form, BorderLayout.CENTER);
        south.add(actions, BorderLayout.SOUTH);
        add(south, BorderLayout.SOUTH);

        btnClear.addActionListener(e -> clearForm());
        btnAdd.addActionListener(e -> doAdd());
        btnUpdate.addActionListener(e -> doUpdate());
        btnDelete.addActionListener(e -> doDelete());

        loadCategories();
        reload();

        // Đăng ký sự kiện thay đổi danh mục → tự reload combobox
        AppEventBus.get().subscribe(AppEventType.CATEGORY_CHANGED, this::reloadCategoriesNow);
        // 🔥 Quan trọng: khi nhập hàng / thay đổi tồn kho → reload bảng ngay
        AppEventBus.get().subscribe(AppEventType.PURCHASE_CHANGED, this::reload);
        AppEventBus.get().subscribe(AppEventType.PRODUCT_CHANGED,  this::reload);
    }

    private Number toNumber(Object v){
        try {
            if (v == null) return 0;
            if (v instanceof Number) return (Number) v;
            String s = v.toString().replace(".", "").replace(",", ".");
            return Double.parseDouble(s);
        } catch (Exception e){ return 0; }
    }

    private void clearForm(){
        currentId = null;
        txtSku.setText("");
        txtName.setText("");
        if (cbCategory.getItemCount() > 0) cbCategory.setSelectedIndex(0);
        txtUnit.setText("");
        fCost.setValue(0);
        fPrice.setValue(0);
        table.clearSelection();
    }

    private void doAdd(){
        try{
            String sku = txtSku.getText().trim();
            String name = txtName.getText().trim();
            Integer catId = getSelectedCategoryId();
            String unit = txtUnit.getText().trim();
            BigDecimal cost = parseMoney(fCost.getValue());
            BigDecimal price = parseMoney(fPrice.getValue());

            if (sku.isEmpty() || name.isEmpty()){
                JOptionPane.showMessageDialog(this, "SKU và Tên không được trống");
                return;
            }
            ProductDAO.insert(sku, name, catId, unit, cost, price);
            reload();
            // phát sự kiện để nơi khác (nếu cần) update
            AppEventBus.get().publish(AppEventType.PRODUCT_CHANGED);
            clearForm();
        } catch (Exception ex){
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void doUpdate(){
        if (currentId == null){
            JOptionPane.showMessageDialog(this, "Hãy chọn 1 sản phẩm để sửa");
            return;
        }
        try{
            String sku = txtSku.getText().trim();
            String name = txtName.getText().trim();
            Integer catId = getSelectedCategoryId();
            String unit = txtUnit.getText().trim();
            BigDecimal cost = parseMoney(fCost.getValue());
            BigDecimal price = parseMoney(fPrice.getValue());

            if (sku.isEmpty() || name.isEmpty()){
                JOptionPane.showMessageDialog(this, "SKU và Tên không được trống");
                return;
            }
            ProductDAO.update(currentId, sku, name, catId, unit, cost, price);
            reload();
            AppEventBus.get().publish(AppEventType.PRODUCT_CHANGED);
        } catch (Exception ex){
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void doDelete(){
        if (currentId == null){
            JOptionPane.showMessageDialog(this, "Hãy chọn 1 sản phẩm để xoá");
            return;
        }
        if (JOptionPane.showConfirmDialog(this, "Xoá sản phẩm này?", "Xác nhận",
                JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try{
            ProductDAO.delete(currentId);
            reload();
            AppEventBus.get().publish(AppEventType.PRODUCT_CHANGED);
            clearForm();
        } catch (Exception ex){
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Integer getSelectedCategoryId(){
        Object it = cbCategory.getSelectedItem();
        if (it instanceof CategoryItem) return ((CategoryItem) it).id();
        return null;
    }

    private void selectCategoryByName(String name){
        for (int i = 0; i < cbCategory.getItemCount(); i++){
            CategoryItem it = cbCategory.getItemAt(i);
            if (it.name().equalsIgnoreCase(name)){
                cbCategory.setSelectedIndex(i);
                return;
            }
        }
    }

    private BigDecimal parseMoney(Object val){
        try{
            if (val == null) return BigDecimal.ZERO;
            if (val instanceof Number) return BigDecimal.valueOf(((Number) val).doubleValue());
            String s = val.toString().replace(".", "").replace(",", ".");
            return new BigDecimal(s);
        }catch(Exception e){ return BigDecimal.ZERO; }
    }

    private void loadCategories(){
        cbCategory.removeAllItems();
        Map<Integer, String> rows = new LinkedHashMap<>();
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT id, name FROM categories ORDER BY name ASC");
             ResultSet rs = ps.executeQuery()){
            while (rs.next()){
                rows.put(rs.getInt(1), rs.getString(2));
            }
        } catch (Exception ignored){}
        cbCategory.addItem(new CategoryItem(null, "(Không)"));
        for (Map.Entry<Integer,String> e : rows.entrySet()){
            cbCategory.addItem(new CategoryItem(e.getKey(), e.getValue()));
        }
    }

    public void reload(){
        SwingUtilities.invokeLater(() -> {
            model.setRowCount(0);
            try (Connection c = DB.getConnection();
                 PreparedStatement ps = c.prepareStatement(
                         "SELECT p.id, p.sku, p.name, COALESCE(c.name,'(Không)'), p.unit, " +
                                 "p.cost_price, p.sale_price, p.stock " +
                                 "FROM products p LEFT JOIN categories c ON p.category_id=c.id " +
                                 "ORDER BY p.id DESC");
                 ResultSet rs = ps.executeQuery()){
                while (rs.next()){
                    model.addRow(new Object[]{
                            rs.getInt(1), rs.getString(2), rs.getString(3),
                            rs.getString(4), rs.getString(5),
                            rs.getBigDecimal(6), rs.getBigDecimal(7),
                            rs.getInt(8)
                    });
                }
            } catch (Exception ex){
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    // Reload lại combobox khi danh mục thay đổi
    private void reloadCategoriesNow() {
        SwingUtilities.invokeLater(() -> {
            Object sel = cbCategory.getSelectedItem();
            String selectedName = null;
            if (sel instanceof CategoryItem it) {
                selectedName = it.name();
            }
            loadCategories();
            if (selectedName != null) {
                selectCategoryByName(selectedName);
            }
        });
    }

    private record CategoryItem(Integer id, String name) {
        @Override public String toString(){ return name; }
    }
}
