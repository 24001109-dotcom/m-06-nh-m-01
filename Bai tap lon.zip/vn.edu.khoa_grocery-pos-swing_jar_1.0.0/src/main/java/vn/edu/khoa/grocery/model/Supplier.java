
package vn.edu.khoa.grocery.model;
public class Supplier { private Integer id; private String name; private String phone; private String address;
  public Supplier(){} public Supplier(Integer id,String name,String phone,String address){ this.id=id; this.name=name; this.phone=phone; this.address=address; }
  public Integer getId(){return id;} public void setId(Integer v){id=v;} public String getName(){return name;} public void setName(String v){name=v;} public String getPhone(){return phone;} public void setPhone(String v){phone=v;} public String getAddress(){return address;} public void setAddress(String v){address=v;}
}
