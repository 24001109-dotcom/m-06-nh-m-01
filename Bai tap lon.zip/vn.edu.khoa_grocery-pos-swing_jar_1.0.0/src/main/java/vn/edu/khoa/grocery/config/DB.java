package vn.edu.khoa.grocery.config;

import java.sql.Connection;
import java.sql.DriverManager;

public class DB {
    private static final String URL =
            "jdbc:mysql://localhost:3306/grocery_db"
            + "?useSSL=false"
            + "&allowPublicKeyRetrieval=true"
            + "&serverTimezone=UTC"
            + "&characterEncoding=utf8";
    private static final String USER = "root";  // XAMPP mặc định
    private static final String PASS = "";      // XAMPP mặc định rỗng

    public static Connection getConnection() throws Exception {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
