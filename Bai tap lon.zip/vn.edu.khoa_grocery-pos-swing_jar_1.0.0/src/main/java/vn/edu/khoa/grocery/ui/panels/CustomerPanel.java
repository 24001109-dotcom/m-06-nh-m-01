package vn.edu.khoa.grocery.ui.panels;

import vn.edu.khoa.grocery.dao.CustomerDAO;
import vn.edu.khoa.grocery.model.Customer;
import vn.edu.khoa.grocery.ui.events.AppEventBus;
import vn.edu.khoa.grocery.ui.events.AppEventType;
import vn.edu.khoa.grocery.ui.theme.UiUtils;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class CustomerPanel extends JPanel {

    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"ID", "Tên", "ĐT", "Địa chỉ"}, 0
    ){
        @Override public boolean isCellEditable(int r, int c){ return false; }
    };
    private final JTable table = new JTable(model);

    private final JTextField fName = new JTextField(22);
    private final JTextField fPhone = new JTextField(14);
    private final JTextField fAddress = new JTextField(30);

    private Integer currentId = null;
    private final CustomerDAO dao = new CustomerDAO();

    public CustomerPanel(){
        setOpaque(false);
        setLayout(new BorderLayout(10,10));

        // ===== Header =====
        JLabel title = new JLabel("Khách hàng");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 18f));
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.add(title, BorderLayout.WEST);
        add(header, BorderLayout.NORTH);

        // ===== Table =====
        UiUtils.styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(this::onRowSelected);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // ===== Form =====
        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6,6,6,6);
        c.anchor = GridBagConstraints.WEST;

        int row = 0;
        c.gridx=0; c.gridy=row; form.add(new JLabel("Tên:"), c);
        c.gridx=1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx=1; form.add(fName, c);
        c.fill = GridBagConstraints.NONE; c.weightx=0;

        row++;
        c.gridx=0; c.gridy=row; form.add(new JLabel("ĐT:"), c);
        c.gridx=1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx=1; form.add(fPhone, c);
        c.fill = GridBagConstraints.NONE; c.weightx=0;

        row++;
        c.gridx=0; c.gridy=row; form.add(new JLabel("Địa chỉ:"), c);
        c.gridx=1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx=1; form.add(fAddress, c);

        // ===== Actions =====
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actions.setOpaque(false);
        JButton btnClear = new JButton("Làm mới");
        JButton btnAdd   = UiUtils.primaryButton("Thêm");
        JButton btnUpdate= UiUtils.primaryButton("Sửa");
        JButton btnDelete= UiUtils.dangerButton("Xóa");
        actions.add(btnClear);
        actions.add(btnAdd);
        actions.add(btnUpdate);
        actions.add(btnDelete);

        JPanel south = new JPanel(new BorderLayout());
        south.setOpaque(false);
        south.add(form, BorderLayout.CENTER);
        south.add(actions, BorderLayout.SOUTH);
        add(south, BorderLayout.SOUTH);

        // events
        btnClear.addActionListener(e -> clearForm());
        btnAdd.addActionListener(e -> doAdd());
        btnUpdate.addActionListener(e -> doUpdate());
        btnDelete.addActionListener(e -> doDelete());

        // data
        reload();
    }

    private void onRowSelected(ListSelectionEvent e){
        if (e.getValueIsAdjusting()) return;
        int r = table.getSelectedRow();
        if (r >= 0){
            currentId = (Integer) model.getValueAt(r, 0);
            fName.setText(String.valueOf(model.getValueAt(r, 1)));
            fPhone.setText(String.valueOf(model.getValueAt(r, 2)));
            fAddress.setText(String.valueOf(model.getValueAt(r, 3)));
        }
    }

    private void clearForm(){
        currentId = null;
        fName.setText("");
        fPhone.setText("");
        fAddress.setText("");
        table.clearSelection();
    }

    private void doAdd(){
        try{
            String name = fName.getText().trim();
            if (name.isEmpty()){
                JOptionPane.showMessageDialog(this, "Tên không được trống");
                return;
            }
            Customer s = new Customer(null, name, fPhone.getText().trim(), fAddress.getText().trim());
            Integer id = dao.insert(s);
            if (id != null){
                reload();
                clearForm();
                AppEventBus.get().publish(AppEventType.CUSTOMER_CHANGED);
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void doUpdate(){
        if (currentId == null){
            JOptionPane.showMessageDialog(this, "Chọn 1 dòng để sửa");
            return;
        }
        try{
            String name = fName.getText().trim();
            if (name.isEmpty()){
                JOptionPane.showMessageDialog(this, "Tên không được trống");
                return;
            }
            Customer s = new Customer(currentId, name, fPhone.getText().trim(), fAddress.getText().trim());
            if (dao.update(s)){
                reload();
                AppEventBus.get().publish(AppEventType.CUSTOMER_CHANGED);
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void doDelete(){
        int r = table.getSelectedRow();
        if (r < 0){
            JOptionPane.showMessageDialog(this, "Chọn 1 dòng để xoá");
            return;
        }
        int id = (Integer) model.getValueAt(r, 0);
        if (JOptionPane.showConfirmDialog(this, "Xoá khách hàng này?\n(Lưu ý: nếu khách đã có đơn hàng, hãy xoá đơn trước hoặc đổi khách)", "Xác nhận",
                JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try{
            if (dao.delete(id)){
                reload();
                clearForm();
                AppEventBus.get().publish(AppEventType.CUSTOMER_CHANGED);
            }
        }catch(Exception ex){
            // Có thể dính ràng buộc FK (đã có đơn hàng), báo lỗi rõ ràng:
            JOptionPane.showMessageDialog(this,
                    "Không thể xoá khách hàng do đã phát sinh đơn hàng.\n" +
                    "Hãy xoá/điều chỉnh các đơn liên quan trước.\n\nChi tiết: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void reload(){
        model.setRowCount(0);
        try{
            List<Customer> list = dao.findAll();
            for (Customer s : list){
                model.addRow(new Object[]{ s.getId(), s.getName(), s.getPhone(), s.getAddress() });
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }
}
