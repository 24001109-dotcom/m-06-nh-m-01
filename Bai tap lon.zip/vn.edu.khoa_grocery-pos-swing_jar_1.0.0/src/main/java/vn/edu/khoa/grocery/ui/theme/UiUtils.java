
package vn.edu.khoa.grocery.ui.theme;
import javax.swing.*; import javax.swing.table.*; import java.awt.*;
public class UiUtils {
  public static JButton primaryButton(String text){
    JButton b = new JButton(text);
    b.putClientProperty("JButton.buttonType","roundRect");
    b.setBackground(new Color(39,174,96));
    b.setForeground(Color.white);
    b.setFocusPainted(false);
    return b;
  }
  public static JButton dangerButton(String text){
    JButton b = new JButton(text);
    b.putClientProperty("JButton.buttonType","roundRect");
    b.setBackground(new Color(192,57,43));
    b.setForeground(Color.white);
    b.setFocusPainted(false);
    return b;
  }
  public static void styleTable(JTable t){
    JTableHeader h = t.getTableHeader();
    h.setOpaque(false);
    h.setBackground(new Color(41, 128, 185));
    h.setForeground(Color.WHITE);
    t.setRowHeight(26);
    t.setFillsViewportHeight(true);
    t.setShowGrid(true);
  }
}
