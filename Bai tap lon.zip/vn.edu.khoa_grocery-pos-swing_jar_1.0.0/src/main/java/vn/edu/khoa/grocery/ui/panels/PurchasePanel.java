package vn.edu.khoa.grocery.ui.panels;

import vn.edu.khoa.grocery.config.DB;
import vn.edu.khoa.grocery.dao.ProductDAO;
import vn.edu.khoa.grocery.ui.theme.UiUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.*;

public class PurchasePanel extends JPanel {
    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"ID","Nhà cung cấp","Ngày nhập","Tổng"},0
    ){
        @Override public boolean isCellEditable(int r,int c){return false;}
    };
    private final JTable table = new JTable(model);

    // ComboBox thay cho JTextField nhập NCC
    private final JComboBox<SupplierItem> cboSupplier = new JComboBox<>();
    private final JTextField txtProductId = new JTextField(6);
    private final JTextField txtQty = new JTextField(6);
    private final JTextField txtPrice = new JTextField(10);

    public PurchasePanel(){
        setLayout(new BorderLayout(10,10));
        setOpaque(false);

        JLabel title = new JLabel("Nhập hàng");
        title.setFont(title.getFont().deriveFont(Font.BOLD,18f));
        add(title, BorderLayout.NORTH);

        UiUtils.styleTable(table);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT));
        form.add(new JLabel("Nhà CC:"));
        form.add(cboSupplier); // combobox chọn nhà cung cấp
        form.add(new JLabel("SP ID:"));
        form.add(txtProductId);
        form.add(new JLabel("SL:"));
        form.add(txtQty);
        form.add(new JLabel("Giá:"));
        form.add(txtPrice);

        JButton btnSave = UiUtils.primaryButton("Nhập kho");
        form.add(btnSave);
        add(form, BorderLayout.SOUTH);

        btnSave.addActionListener(e -> doSave());

        loadSuppliers(); // load danh sách NCC từ DB
        reload();
    }

    /** Tải danh sách nhà cung cấp vào combobox */
    private void loadSuppliers(){
        cboSupplier.removeAllItems();
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT id,name FROM suppliers ORDER BY name");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()){
                cboSupplier.addItem(new SupplierItem(rs.getInt(1), rs.getString(2)));
            }
        } catch(Exception ex){
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** Thực hiện nhập kho */
    private void doSave(){
        SupplierItem sup = (SupplierItem) cboSupplier.getSelectedItem();
        if (sup == null){
            JOptionPane.showMessageDialog(this, "Chưa chọn nhà cung cấp");
            return;
        }

        int productId, qty;
        BigDecimal price;
        try{
            productId = Integer.parseInt(txtProductId.getText().trim());
            qty = Integer.parseInt(txtQty.getText().trim());
            price = new BigDecimal(txtPrice.getText().trim());
        }catch(Exception ex){
            JOptionPane.showMessageDialog(this,"Dữ liệu không hợp lệ");
            return;
        }

        try(Connection c = DB.getConnection()){
            c.setAutoCommit(false);

            // 1) thêm purchase_orders
            int poId;
            try(PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO purchase_orders(supplier_id, order_date, total) VALUES (?,?,?)",
                    Statement.RETURN_GENERATED_KEYS)){
                ps.setInt(1,sup.id);
                ps.setDate(2,new java.sql.Date(System.currentTimeMillis()));
                ps.setBigDecimal(3, price.multiply(BigDecimal.valueOf(qty)));
                ps.executeUpdate();
                try(ResultSet rs = ps.getGeneratedKeys()){rs.next(); poId = rs.getInt(1);}
            }

            // 2) thêm purchase_items
            try(PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO purchase_items(order_id, product_id, qty, price) VALUES (?,?,?,?)")){
                ps.setInt(1,poId);
                ps.setInt(2,productId);
                ps.setInt(3,qty);
                ps.setBigDecimal(4,price);
                ps.executeUpdate();
            }

            // stock cập nhật qua trigger → không gọi addStock nữa
            c.commit();

            JOptionPane.showMessageDialog(this,"Đã nhập kho");
            reload();
            SwingUtilities.invokeLater(OrdersPanel::reloadStaticIfAny);
            SwingUtilities.invokeLater(ProductPanel::reloadStaticIfAny);

        }catch(Exception ex){
            JOptionPane.showMessageDialog(this,ex.getMessage(),"Lỗi",JOptionPane.ERROR_MESSAGE);
        }
    }

    /** Reload lại bảng đơn nhập hàng */
    private void reload(){
        model.setRowCount(0);
        try(Connection c = DB.getConnection();
            PreparedStatement ps = c.prepareStatement(
                    "SELECT po.id, s.name, po.order_date, po.total " +
                    "FROM purchase_orders po JOIN suppliers s ON po.supplier_id=s.id ORDER BY po.id DESC");
            ResultSet rs = ps.executeQuery()){
            while(rs.next()){
                model.addRow(new Object[]{rs.getInt(1),rs.getString(2),rs.getDate(3),rs.getBigDecimal(4)});
            }
        }catch(Exception ignored){}
    }

    /** Item để hiển thị tên và lưu id nhà cung cấp */
    static class SupplierItem {
        int id;
        String name;
        SupplierItem(int id, String name){ this.id=id; this.name=name; }
        @Override public String toString(){ return name; }
    }
}
