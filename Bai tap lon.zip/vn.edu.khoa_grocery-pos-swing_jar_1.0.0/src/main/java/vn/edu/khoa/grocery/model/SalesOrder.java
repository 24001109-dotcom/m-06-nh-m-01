
package vn.edu.khoa.grocery.model;
import java.time.LocalDate;
public class SalesOrder { private Integer id; private Integer customerId; private LocalDate orderDate; private double total;
  public SalesOrder(){} public SalesOrder(Integer id,Integer customerId,LocalDate date,double total){ this.id=id; this.customerId=customerId; this.orderDate=date; this.total=total; }
  public Integer getId(){return id;} public void setId(Integer v){id=v;} public Integer getCustomerId(){return customerId;} public void setCustomerId(Integer v){customerId=v;}
  public LocalDate getOrderDate(){return orderDate;} public void setOrderDate(LocalDate v){orderDate=v;} public double getTotal(){return total;} public void setTotal(double v){total=v;}
}
