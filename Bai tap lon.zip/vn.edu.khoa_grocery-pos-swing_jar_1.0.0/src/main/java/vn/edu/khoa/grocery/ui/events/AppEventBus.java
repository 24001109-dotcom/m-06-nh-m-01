
package vn.edu.khoa.grocery.ui.events;
import java.util.*; import javax.swing.SwingUtilities;
public class AppEventBus {
  private static final AppEventBus INSTANCE = new AppEventBus();
  public static AppEventBus get(){ return INSTANCE; }
  private final Map<AppEventType, List<Runnable>> listeners = new EnumMap<>(AppEventType.class);
  private AppEventBus(){
    for(AppEventType t: AppEventType.values()) listeners.put(t, new ArrayList<>());
  }
  public synchronized void subscribe(AppEventType type, Runnable r){
    listeners.get(type).add(r);
  }
  public void publish(AppEventType type){
    List<Runnable> ls;
    synchronized(this){ ls = new ArrayList<>(listeners.get(type)); }
    for(Runnable r: ls){
      SwingUtilities.invokeLater(r); // đảm bảo chạy trên EDT để update UI an toàn
    }
  }
}
