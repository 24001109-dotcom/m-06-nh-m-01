package vn.edu.khoa.grocery.ui;

import vn.edu.khoa.grocery.dao.CustomerDAO;
import vn.edu.khoa.grocery.model.Customer;

import javax.swing.*;
import java.awt.*;

/**
 * Dialog cho khách nhập tên/SĐT/địa chỉ để vào mua hàng.
 * - Nếu tên trùng sẽ tự gợi ý tên mới (name_1, name_2, ...)
 * - Lưu vào bảng customers và trả ra customerId, customerName
 */
public class CustomerLoginDialog extends JDialog {

    private final JTextField txtName = new JTextField(20);
    private final JTextField txtPhone = new JTextField(15);
    private final JTextField txtAddress = new JTextField(25);

    private Integer customerId;   // trả về khi OK
    private String customerName;  // tên cuối cùng được lưu

    public CustomerLoginDialog(Window owner) {
        super(owner, "Khách mua hàng", ModalityType.APPLICATION_MODAL);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(400, 250);
        setLocationRelativeTo(owner);

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8);
        c.anchor = GridBagConstraints.WEST;

        int row = 0;
        c.gridx=0; c.gridy=row; form.add(new JLabel("Tên khách hàng:"), c);
        c.gridx=1; c.fill=GridBagConstraints.HORIZONTAL; c.weightx=1; form.add(txtName, c);

        row++;
        c.gridx=0; c.gridy=row; c.fill=GridBagConstraints.NONE; c.weightx=0; form.add(new JLabel("Số điện thoại:"), c);
        c.gridx=1; c.fill=GridBagConstraints.HORIZONTAL; c.weightx=1; form.add(txtPhone, c);

        row++;
        c.gridx=0; c.gridy=row; c.fill=GridBagConstraints.NONE; c.weightx=0; form.add(new JLabel("Địa chỉ:"), c);
        c.gridx=1; c.fill=GridBagConstraints.HORIZONTAL; c.weightx=1; form.add(txtAddress, c);

        JButton btnOk = new JButton("OK");
        JButton btnCancel = new JButton("Hủy");

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actions.add(btnOk);
        actions.add(btnCancel);

        getContentPane().setLayout(new BorderLayout(10,10));
        getContentPane().add(form, BorderLayout.CENTER);
        getContentPane().add(actions, BorderLayout.SOUTH);

        btnOk.addActionListener(e -> doSave());
        btnCancel.addActionListener(e -> dispose());
    }

    private void doSave() {
        String name = txtName.getText().trim();
        String phone = txtPhone.getText().trim();
        String address = txtAddress.getText().trim();

        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tên khách hàng không được để trống");
            return;
        }

        try {
            // Dùng instance CustomerDAO (tránh lỗi non-static)
            CustomerDAO dao = new CustomerDAO();

            // Nếu tên trùng → tự gợi ý name_1, name_2, ...
            String base = name;
            int suffix = 1;
            while (CustomerDAO.existsByName(name)) {
                name = base + "_" + suffix;
                suffix++;
            }

            // Insert và lấy id mới
            Customer cst = new Customer(name, phone, address);
            Integer id = dao.insert(cst);
            if (id == null) {
                JOptionPane.showMessageDialog(this, "Không thể tạo khách hàng, vui lòng thử lại!");
                return;
            }

            this.customerId = id;
            this.customerName = name;

            JOptionPane.showMessageDialog(this, "Đăng nhập thành công với tên: " + name);
            dispose();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    public Integer getCustomerId() { return customerId; }
    public String getCustomerName() { return customerName; }
}
