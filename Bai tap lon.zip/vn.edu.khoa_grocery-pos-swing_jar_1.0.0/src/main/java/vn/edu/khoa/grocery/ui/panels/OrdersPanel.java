package vn.edu.khoa.grocery.ui.panels;

import vn.edu.khoa.grocery.config.DB;
import vn.edu.khoa.grocery.ui.events.AppEventBus;
import vn.edu.khoa.grocery.ui.events.AppEventType;
import vn.edu.khoa.grocery.ui.theme.UiUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.FileWriter;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 * Panel Đơn hàng
 * - Hai tab: Đơn nhập (purchase_orders) và Đơn bán (sales_orders)
 * - Tự động reload khi có sự kiện PURCHASE_CHANGED / SALE_CHANGED được publish
 * - Có nút Export CSV cho mỗi tab
 */
public class OrdersPanel extends JPanel {

    static void reloadStaticIfAny() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Purchase
    private final DefaultTableModel mPurchase = new DefaultTableModel(
            new Object[]{"ID","Nhà cung cấp","Ngày nhập","Tổng"},0
    ){
        @Override public boolean isCellEditable(int r,int c){return false;}
    };
    private final JTable tPurchase = new JTable(mPurchase);

    // Sales
    private final DefaultTableModel mSales = new DefaultTableModel(
            new Object[]{"ID","Khách hàng","Ngày bán","Tổng"},0
    ){
        @Override public boolean isCellEditable(int r,int c){return false;}
    };
    private final JTable tSales = new JTable(mSales);

    public OrdersPanel(){
        setLayout(new BorderLayout(10,10));
        setOpaque(false);

        JLabel title = new JLabel("Đơn hàng");
        title.setFont(title.getFont().deriveFont(Font.BOLD,18f));
        add(title, BorderLayout.NORTH);

        if (hasUiUtils()){
            UiUtils.styleTable(tPurchase);
            UiUtils.styleTable(tSales);
        }

        // tabs
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Đơn nhập", makePurchaseTab());
        tabs.addTab("Đơn bán", makeSalesTab());
        add(tabs, BorderLayout.CENTER);

        // subscribe sự kiện
        AppEventBus.get().subscribe(AppEventType.PURCHASE_CHANGED, this::reloadPurchase);
        AppEventBus.get().subscribe(AppEventType.SALE_CHANGED, this::reloadSales);

        // initial
        reloadPurchase();
        reloadSales();
    }

    private boolean hasUiUtils(){
        try {
            Class.forName("vn.edu.khoa.grocery.ui.theme.UiUtils");
            return true;
        } catch (Throwable t){
            return false;
        }
    }

    private JPanel makePurchaseTab(){
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(tPurchase), BorderLayout.CENTER);

        JButton btnReload = new JButton("Tải lại");
        JButton btnExport = new JButton("Xuất CSV");
        if (hasUiUtils()){
            btnReload = UiUtils.primaryButton("Tải lại");
            btnExport = UiUtils.primaryButton("Xuất CSV");
        }

        btnReload.addActionListener(e -> reloadPurchase());
        btnExport.addActionListener(e -> exportCsv(tPurchase, "purchase_orders.csv"));

        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        south.add(btnReload);
        south.add(btnExport);
        panel.add(south, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel makeSalesTab(){
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(tSales), BorderLayout.CENTER);

        JButton btnReload = new JButton("Tải lại");
        JButton btnExport = new JButton("Xuất CSV");
        if (hasUiUtils()){
            btnReload = UiUtils.primaryButton("Tải lại");
            btnExport = UiUtils.primaryButton("Xuất CSV");
        }

        btnReload.addActionListener(e -> reloadSales());
        btnExport.addActionListener(e -> exportCsv(tSales, "sales_orders.csv"));

        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        south.add(btnReload);
        south.add(btnExport);
        panel.add(south, BorderLayout.SOUTH);
        return panel;
    }

    /** Nạp lại bảng Đơn nhập */
    private void reloadPurchase(){
        SwingUtilities.invokeLater(() -> {
            mPurchase.setRowCount(0);
            try (Connection c = DB.getConnection();
                 PreparedStatement ps = c.prepareStatement(
                         "SELECT po.id, s.name, po.order_date, po.total " +
                         "FROM purchase_orders po JOIN suppliers s ON po.supplier_id=s.id " +
                         "ORDER BY po.id DESC");
                 ResultSet rs = ps.executeQuery()){
                while (rs.next()){
                    mPurchase.addRow(new Object[]{
                            rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getBigDecimal(4)
                    });
                }
            } catch (Exception ex){
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    /** Nạp lại bảng Đơn bán */
    private void reloadSales(){
        SwingUtilities.invokeLater(() -> {
            mSales.setRowCount(0);
            try (Connection c = DB.getConnection();
                 PreparedStatement ps = c.prepareStatement(
                         "SELECT s.id, COALESCE(c.name,'Khách lẻ'), s.order_date, s.total " +
                         "FROM sales_orders s LEFT JOIN customers c ON s.customer_id=c.id " +
                         "ORDER BY s.id DESC");
                 ResultSet rs = ps.executeQuery()){
                while (rs.next()){
                    mSales.addRow(new Object[]{
                            rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getBigDecimal(4)
                    });
                }
            } catch (Exception ex){
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    /** Xuất CSV đơn giản cho bảng hiện tại */
    private void exportCsv(JTable table, String defaultName){
        try{
            JFileChooser fc = new JFileChooser();
            fc.setSelectedFile(new java.io.File(defaultName));
            if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;

            try (FileWriter fw = new FileWriter(fc.getSelectedFile(), false)){
                DefaultTableModel m = (DefaultTableModel) table.getModel();
                // header
                for (int c = 0; c < m.getColumnCount(); c++){
                    if (c > 0) fw.write(",");
                    fw.write(escapeCsv(m.getColumnName(c)));
                }
                fw.write("\n");
                // rows
                for (int r = 0; r < m.getRowCount(); r++){
                    for (int c = 0; c < m.getColumnCount(); c++){
                        if (c > 0) fw.write(",");
                        Object v = m.getValueAt(r, c);
                        fw.write(escapeCsv(v == null ? "" : String.valueOf(v)));
                    }
                    fw.write("\n");
                }
            }
            JOptionPane.showMessageDialog(this, "Đã xuất CSV.");
        } catch (Exception ex){
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi xuất CSV", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String escapeCsv(String s){
        String t = s.replace("\"","\"\"");
        return "\"" + t + "\"";
    }
}
