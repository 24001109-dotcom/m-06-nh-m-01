
package vn.edu.khoa.grocery.ui.components;

import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class ReceiptPDF {
  public static void export(String path, String title, String customerName, Object[][] lines, double subtotal, double discount, double total) throws Exception {
    Document doc = new Document(PageSize.A4, 36, 36, 36, 36);
    PdfWriter.getInstance(doc, new FileOutputStream(path));
    doc.open();
    var nf = NumberFormat.getNumberInstance(new Locale("vi","VN"));

    // header
    Paragraph pTitle = new Paragraph(title, FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16));
    pTitle.setAlignment(Element.ALIGN_CENTER);
    doc.add(pTitle);
    doc.add(new Paragraph("Ngày: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))));
    doc.add(new Paragraph("Khách hàng: " + (customerName==null?"Khách lẻ":customerName)));
    doc.add(new Paragraph(" "));

    // table
    PdfPTable table = new PdfPTable(new float[]{10,30,15,10,10,10,15});
    table.setWidthPercentage(100);
    addHeader(table, "ID","Tên","Đơn vị","Giá","SL","CK%","Thành tiền");
    for(Object[] row : lines){
      for(Object cell : row){
        PdfPCell c = new PdfPCell(new Phrase(String.valueOf(cell)));
        c.setPadding(4);
        table.addCell(c);
      }
    }
    doc.add(table);

    doc.add(new Paragraph(" "));
    doc.add(new Paragraph("Tạm tính: " + nf.format(subtotal)));
    doc.add(new Paragraph("Chiết khấu: " + nf.format(discount)));
    doc.add(new Paragraph("TỔNG: " + nf.format(total), FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14)));

    doc.close();
  }

  private static void addHeader(PdfPTable t, String... cols){
    for(String s: cols){
      PdfPCell c = new PdfPCell(new Phrase(s, FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10)));
      c.setPadding(5);
      t.addCell(c);
    }
  }
}
