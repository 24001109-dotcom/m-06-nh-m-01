package vn.edu.khoa.grocery.ui;

import vn.edu.khoa.grocery.dao.UserDAO;
import vn.edu.khoa.grocery.model.User;
import org.mindrot.jbcrypt.BCrypt;

import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {
    private final JTextField txtUser = new JTextField(18);
    private final JPasswordField txtPass = new JPasswordField(18);
    private final JButton btnLogin = new JButton("Đăng nhập");
    private final JButton btnGuest = new JButton("Khách mua hàng");
    private final JButton btnExit  = new JButton("Thoát");

    public LoginFrame() {
        super("Đăng nhập hệ thống tạp hoá");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(420, 260);
        setLocationRelativeTo(null);

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8);
        c.anchor = GridBagConstraints.WEST;

        int row = 0;
        c.gridx=0; c.gridy=row; form.add(new JLabel("Tên đăng nhập:"), c);
        c.gridx=1; c.fill=GridBagConstraints.HORIZONTAL; c.weightx=1; form.add(txtUser, c);

        row++;
        c.gridx=0; c.gridy=row; c.fill=GridBagConstraints.NONE; c.weightx=0; form.add(new JLabel("Mật khẩu:"), c);
        c.gridx=1; c.fill=GridBagConstraints.HORIZONTAL; c.weightx=1; form.add(txtPass, c);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actions.add(btnGuest);
        actions.add(btnLogin);
        actions.add(btnExit);

        getContentPane().setLayout(new BorderLayout(10,10));
        getContentPane().add(form, BorderLayout.CENTER);
        getContentPane().add(actions, BorderLayout.SOUTH);

        btnLogin.addActionListener(e -> doLogin());
        btnGuest.addActionListener(e -> openGuestFlow());
        btnExit.addActionListener(e -> System.exit(0));

        getRootPane().setDefaultButton(btnLogin);
    }

    private void doLogin() {
        String u = txtUser.getText() == null ? "" : txtUser.getText().trim();
        String p = new String(txtPass.getPassword());
        p = p == null ? "" : p.trim();

        if (u.isEmpty() || p.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nhập đầy đủ tài khoản và mật khẩu");
            return;
        }

        try {
            // DB đang kết nối là gì?
            try (var c = vn.edu.khoa.grocery.config.DB.getConnection();
                 var st = c.createStatement();
                 var rs = st.executeQuery("SELECT DATABASE()")) {
                if (rs.next()) System.out.println("[DEBUG] DATABASE()=" + rs.getString(1));
            } catch (Exception ignore){}

            System.out.println("[LOGIN] try: u=" + u);
            User user = UserDAO.findByUsername(u);

            if (user == null) {
                System.out.println("[LOGIN] user not found in DB");
                JOptionPane.showMessageDialog(this, "Sai tài khoản hoặc mật khẩu");
                return;
            }

            String stored = user.getPasswordHash();
            System.out.println("[LOGIN] from DB: username=" + user.getUsername()
                    + ", role=" + user.getRole()
                    + ", pass(len)=" + (stored == null ? "null" : stored.length())
                    + ", startsWith$2? " + (stored != null && stored.startsWith("$2")));

            boolean ok;
            if (stored != null && (stored.startsWith("$2a$") || stored.startsWith("$2b$") || stored.startsWith("$2y$"))) {
                ok = BCrypt.checkpw(p, stored);
                System.out.println("[LOGIN] BCrypt.checkpw=" + ok);
            } else {
                ok = p.equals(stored);
                System.out.println("[LOGIN] Plain compare=" + ok + " (stored=" + stored + ")");
            }

            if (!ok) {
                JOptionPane.showMessageDialog(this, "Sai tài khoản hoặc mật khẩu");
                return;
            }

            SwingUtilities.invokeLater(() -> {
                new AdminFrame(user.getUsername()).setVisible(true);
                dispose();
            });

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void openGuestFlow() {
        try {
            CustomerLoginDialog dlg = new CustomerLoginDialog(this);
            dlg.setVisible(true);
            if (dlg.getCustomerId() != null) {
                new UserFrame(dlg.getCustomerId(), dlg.getCustomerName()).setVisible(true);
                dispose();
            }
        } catch (Throwable ignored) {
            JOptionPane.showMessageDialog(this, "Chức năng khách mua hàng tạm thời không khả dụng.");
        }
    }
}
