package vn.edu.khoa.grocery.ui.components;

import vn.edu.khoa.grocery.config.DB;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

/**
 * Hộp thoại hiển thị hóa đơn sau khi khách thanh toán.
 * Được gọi từ UserFrame:
 *   new InvoiceDialog(this, orderId, customerName, rows, total).setVisible(true);
 *
 * rows: Vector các dòng giỏ hàng, mỗi dòng: {Tên SP, SL, Giá, Thành tiền}
 */
public class InvoiceDialog extends JDialog {

    private final int orderId;
    private final String customerName;
    private final BigDecimal total;

    private final JLabel lblHeader = new JLabel();
    private final JLabel lblSub = new JLabel();
    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"Sản phẩm", "SL", "Giá", "Thành tiền"}, 0
    ){
        @Override public boolean isCellEditable(int r, int c){ return false; }
    };
    private final JTable table = new JTable(model);

    public InvoiceDialog(Window owner,
                         int orderId,
                         String customerName,
                         Vector<Vector<Object>> rows,
                         BigDecimal total) {
        super(owner, "Hóa đơn #" + orderId, ModalityType.APPLICATION_MODAL);
        this.orderId = orderId;
        this.customerName = customerName;
        this.total = total == null ? BigDecimal.ZERO : total;

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(760, 520);
        setLocationRelativeTo(owner);

        // Header
        lblHeader.setFont(lblHeader.getFont().deriveFont(Font.BOLD, 16f));
        lblSub.setForeground(new Color(90, 90, 90));

        JPanel header = new JPanel(new GridLayout(2,1));
        header.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        header.add(lblHeader);
        header.add(lblSub);

        // Table
        table.setRowHeight(24);
        JScrollPane sp = new JScrollPane(table);

        // Bottom actions
        JLabel lblTotal = new JLabel("Tổng tiền: " + formatMoney(this.total));
        lblTotal.setFont(lblTotal.getFont().deriveFont(Font.BOLD, 14f));

        JButton btnClose = new JButton("Đóng");
        btnClose.addActionListener(e -> dispose());

        JPanel footerLeft = new JPanel(new FlowLayout(FlowLayout.LEFT));
        footerLeft.add(lblTotal);

        JPanel footerRight = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        footerRight.add(btnClose);

        JPanel footer = new JPanel(new BorderLayout());
        footer.setBorder(BorderFactory.createEmptyBorder(8,10,8,10));
        footer.add(footerLeft, BorderLayout.WEST);
        footer.add(footerRight, BorderLayout.EAST);

        // Layout
        getContentPane().setLayout(new BorderLayout(0,8));
        getContentPane().add(header, BorderLayout.NORTH);
        getContentPane().add(sp, BorderLayout.CENTER);
        getContentPane().add(footer, BorderLayout.SOUTH);

        // Data
        fillInfoFromDB();         // lấy ngày đơn hàng thật từ DB (nếu có)
        loadCartRows(rows);       // đổ chi tiết giỏ hàng vào bảng
    }

    /** Lấy ngày tạo đơn (và tổng nếu muốn xác nhận) từ DB để hiển thị cho chuẩn */
    private void fillInfoFromDB() {
        String dateStr = "";
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT order_date, total FROM sales_orders WHERE id=?")) {
            ps.setInt(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    dateStr = String.valueOf(rs.getDate(1));
                }
            }
        } catch (Exception ignored){}

        lblHeader.setText(String.format("Hóa đơn #%d  •  Khách: %s", orderId, customerName));
        lblSub.setText("Ngày: " + (dateStr.isEmpty() ? "-" : dateStr));
    }

    private void loadCartRows(Vector<Vector<Object>> rows) {
        model.setRowCount(0);
        if (rows != null) {
            for (Vector<Object> r : rows) {
                // Kỳ vọng: r = {Tên SP, SL, Giá, Thành tiền}
                model.addRow(r.toArray());
            }
        }
    }

    private String formatMoney(BigDecimal m) {
        if (m == null) return "0";
        // Định dạng đơn giản (có thể thay bằng NumberFormat nếu muốn)
        return m.stripTrailingZeros().toPlainString();
    }
}
