package vn.edu.khoa.grocery;

import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.*;

import vn.edu.khoa.grocery.ui.LoginFrame;

public class AppMain {
  public static void main(String[] args){
    SwingUtilities.invokeLater(() -> {
      try { FlatLightLaf.setup(); } catch (Exception ignored){}
    
      new LoginFrame().setVisible(true);
    });
  }
}
