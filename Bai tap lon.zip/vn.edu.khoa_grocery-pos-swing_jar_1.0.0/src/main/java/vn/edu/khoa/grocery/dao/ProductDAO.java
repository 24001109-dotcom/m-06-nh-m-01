package vn.edu.khoa.grocery.dao;

import vn.edu.khoa.grocery.config.DB;

import java.math.BigDecimal;
import java.sql.*;

public class ProductDAO {

    /** Thêm sản phẩm mới. TỒN KHO = 0 (không nhập tay) */
    public static void insert(String sku, String name, Integer categoryId,
                              String unit, BigDecimal costPrice, BigDecimal salePrice) throws Exception {
        String sql = "INSERT INTO products (sku, name, category_id, unit, cost_price, sale_price, stock) " +
                "VALUES (?,?,?,?,?,?,0)";
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, sku);
            ps.setString(2, name);
            if (categoryId == null) ps.setNull(3, Types.INTEGER);
            else ps.setInt(3, categoryId);
            ps.setString(4, unit);
            ps.setBigDecimal(5, costPrice == null ? BigDecimal.ZERO : costPrice);
            ps.setBigDecimal(6, salePrice == null ? BigDecimal.ZERO : salePrice);
            ps.executeUpdate();
        }
    }

    /** Cập nhật thông tin sản phẩm. KHÔNG cập nhật stock ở đây */
    public static void update(int id, String sku, String name, Integer categoryId,
                              String unit, BigDecimal costPrice, BigDecimal salePrice) throws Exception {
        String sql = "UPDATE products SET sku=?, name=?, category_id=?, unit=?, cost_price=?, sale_price=? WHERE id=?";
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, sku);
            ps.setString(2, name);
            if (categoryId == null) ps.setNull(3, Types.INTEGER);
            else ps.setInt(3, categoryId);
            ps.setString(4, unit);
            ps.setBigDecimal(5, costPrice == null ? BigDecimal.ZERO : costPrice);
            ps.setBigDecimal(6, salePrice == null ? BigDecimal.ZERO : salePrice);
            ps.setInt(7, id);
            ps.executeUpdate();
        }
    }

    /** Xoá sản phẩm */
    public static void delete(int id) throws Exception {
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM products WHERE id=?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    /** Lấy tồn kho hiện tại (để kiểm tra khi bán) */
    public static int findStock(int productId) throws Exception {
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT stock FROM products WHERE id=?")) {
            ps.setInt(1, productId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
                return 0;
            }
        }
    }

    /** Tìm ID theo SKU (trả về null nếu không có) */
    public static Integer findIdBySku(String sku) throws Exception {
        if (sku == null || sku.isBlank()) return null;
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT id FROM products WHERE sku=? LIMIT 1")) {
            ps.setString(1, sku.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
                return null;
            }
        }
    }

    /** Kiểm tra tồn tại theo ID */
    public static boolean existsById(int id) throws Exception {
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT 1 FROM products WHERE id=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /** No-op để tránh lỗi compile cũ (stock đã do trigger cập nhật) */
    public static void addStock(int productId, int delta) throws Exception { /* no-op */ }
    // ======= Thêm vào cuối class ProductDAO =======

/** Tìm id theo TÊN sản phẩm (exact match). Trả về null nếu không thấy. */
public static Integer findProductIdByName(String name, Connection c) throws Exception {
    if (name == null || name.isBlank()) return null;
    String sql = "SELECT id FROM products WHERE name = ? LIMIT 1";
    try (PreparedStatement ps = c.prepareStatement(sql)) {
        ps.setString(1, name.trim());
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
            return null;
        }
    }
}

/** Overload tiện dùng khi bạn không có sẵn Connection. */
public static Integer findProductIdByName(String name) throws Exception {
    try (Connection c = DB.getConnection()) {
        return findProductIdByName(name, c);
    }
}

/** Tìm id theo SKU HOẶC TÊN (ưu tiên SKU nếu là duy nhất). */
public static Integer findIdBySkuOrName(String key) throws Exception {
    if (key == null || key.isBlank()) return null;
    try (Connection c = DB.getConnection()) {
        // thử SKU
        Integer id = findIdBySku(key);
        if (id != null) return id;
        // thử theo tên
        return findProductIdByName(key, c);
    }
}

}
