
package vn.edu.khoa.grocery.model;
public class SalesItem { private Integer id; private Integer orderId; private Integer productId; private int qty; private double price;
  public SalesItem(){} public SalesItem(Integer id,Integer orderId,Integer productId,int qty,double price){ this.id=id; this.orderId=orderId; this.productId=productId; this.qty=qty; this.price=price; }
  public Integer getId(){return id;} public void setId(Integer v){id=v;} public Integer getOrderId(){return orderId;} public void setOrderId(Integer v){orderId=v;}
  public Integer getProductId(){return productId;} public void setProductId(Integer v){productId=v;} public int getQty(){return qty;} public void setQty(int v){qty=v;} public double getPrice(){return price;} public void setPrice(double v){price=v;}
}
