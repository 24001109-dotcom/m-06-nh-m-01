package vn.edu.khoa.grocery.ui.panels;

import vn.edu.khoa.grocery.config.DB;
import vn.edu.khoa.grocery.dao.ProductDAO;
import vn.edu.khoa.grocery.ui.events.AppEventBus;
import vn.edu.khoa.grocery.ui.events.AppEventType;
import vn.edu.khoa.grocery.ui.theme.UiUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.*;

/**
 * Panel Xuất bán
 * - Bảng hiển thị đơn bán (sales_orders)
 * - Form bán nhanh: (Khách hàng), product_id, qty, price
 * - Dùng AppEventBus:
 *      + publish SALE_CHANGED sau khi bán
 *      + subscribe SALE_CHANGED -> reload()
 *      + subscribe CUSTOMER_CHANGED -> reloadCustomers()
 *      + publish PRODUCT_CHANGED để ProductPanel có thể tự reload nếu muốn
 */
public class SalesPanel extends JPanel {

    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"ID", "Khách hàng", "Ngày bán", "Tổng tiền"}, 0
    ){
        @Override public boolean isCellEditable(int r, int c){ return false; }
    };
    private final JTable table = new JTable(model);

    // Chọn khách hàng (có thể để trống coi như khách lẻ)
    private final JComboBox<CustomerItem> cboCustomer = new JComboBox<>();
    private final JTextField txtProductId = new JTextField(6);
    private final JTextField txtQty       = new JTextField(6);
    private final JTextField txtPrice     = new JTextField(10);

    public SalesPanel(){
        setLayout(new BorderLayout(10,10));
        setOpaque(false);

        JLabel title = new JLabel("Bán hàng");
        title.setFont(title.getFont().deriveFont(Font.BOLD,18f));
        add(title, BorderLayout.NORTH);

        if (hasUiUtils()){
            UiUtils.styleTable(table);
        }
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT));
        form.add(new JLabel("Khách:"));
        form.add(cboCustomer);
        form.add(new JLabel("SP ID:"));
        form.add(txtProductId);
        form.add(new JLabel("SL:"));
        form.add(txtQty);
        form.add(new JLabel("Giá:"));
        form.add(txtPrice);

        JButton btnSave = hasUiUtils() ? UiUtils.primaryButton("Xuất bán") : new JButton("Xuất bán");
        form.add(btnSave);
        add(form, BorderLayout.SOUTH);

        btnSave.addActionListener(e -> doSave());

        // Subscriptions
        AppEventBus.get().subscribe(AppEventType.SALE_CHANGED, this::reload);
        AppEventBus.get().subscribe(AppEventType.CUSTOMER_CHANGED, this::reloadCustomers);

        // Initial
        reloadCustomers();
        reload();
    }

    private boolean hasUiUtils(){
        try {
            Class.forName("vn.edu.khoa.grocery.ui.theme.UiUtils");
            return true;
        } catch (Throwable t){
            return false;
        }
    }

    /** Lấy danh sách khách hàng vào combobox */
    private void reloadCustomers(){
        SwingUtilities.invokeLater(() -> {
            cboCustomer.removeAllItems();
            // Thêm lựa chọn khách lẻ
            cboCustomer.addItem(new CustomerItem(null, "Khách lẻ"));
            try (Connection c = DB.getConnection();
                 PreparedStatement ps = c.prepareStatement(
                         "SELECT id, name FROM customers ORDER BY name ASC");
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()){
                    cboCustomer.addItem(new CustomerItem(rs.getInt(1), rs.getString(2)));
                }
            } catch (Exception ex){
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    /** Thực hiện tạo đơn bán + chi tiết bán */
    private void doSave(){
        Integer customerId = null;
        Object sel = cboCustomer.getSelectedItem();
        if (sel instanceof CustomerItem it) customerId = it.id;

        final int productId, qty;
        final BigDecimal price;
        try{
            productId = Integer.parseInt(txtProductId.getText().trim());
            qty       = Integer.parseInt(txtQty.getText().trim());
            price     = new BigDecimal(txtPrice.getText().trim());
        }catch(Exception ex){
            JOptionPane.showMessageDialog(this, "Dữ liệu không hợp lệ");
            return;
        }

        // Kiểm tra tồn kho
        try{
            int current = ProductDAO.findStock(productId);
            if (qty > current){
                JOptionPane.showMessageDialog(this, "Số lượng bán vượt tồn kho! Tồn hiện tại: " + current);
                return;
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Ghi DB
        try (Connection c = DB.getConnection()){
            c.setAutoCommit(false);

            // 1) sales_orders
            int soId;
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO sales_orders(customer_id, order_date, total) VALUES (?,?,?)",
                    Statement.RETURN_GENERATED_KEYS)) {
                if (customerId == null) ps.setNull(1, Types.INTEGER); else ps.setInt(1, customerId);
                ps.setDate(2, new java.sql.Date(System.currentTimeMillis()));
                ps.setBigDecimal(3, price.multiply(BigDecimal.valueOf(qty)));
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()){
                    rs.next(); soId = rs.getInt(1);
                }
            }

            // 2) sales_items
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO sales_items(order_id, product_id, qty, price) VALUES (?,?,?,?)")) {
                ps.setInt(1, soId);
                ps.setInt(2, productId);
                ps.setInt(3, qty);
                ps.setBigDecimal(4, price);
                ps.executeUpdate();
            }

            // stock sẽ giảm nhờ trigger (nếu có). Nếu chưa tạo trigger, bạn có thể tự UPDATE products SET stock=stock-? WHERE id=?
            c.commit();

            JOptionPane.showMessageDialog(this, "Đã xuất bán");

            // Clear form
            txtProductId.setText("");
            txtQty.setText("");
            txtPrice.setText("");

            // Reload local
            reload();

            // Phát sự kiện toàn cục cho màn khác
            AppEventBus.get().publish(AppEventType.SALE_CHANGED);
            AppEventBus.get().publish(AppEventType.PRODUCT_CHANGED);

        } catch (Exception ex){
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** Nạp lại bảng đơn bán */
    private void reload(){
        SwingUtilities.invokeLater(() -> {
            model.setRowCount(0);
            try (Connection c = DB.getConnection();
                 PreparedStatement ps = c.prepareStatement(
                         "SELECT s.id, COALESCE(c.name,'Khách lẻ'), s.order_date, s.total " +
                                 "FROM sales_orders s LEFT JOIN customers c ON s.customer_id=c.id " +
                                 "ORDER BY s.id DESC");
                 ResultSet rs = ps.executeQuery()){
                while (rs.next()){
                    model.addRow(new Object[]{
                            rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getBigDecimal(4)
                    });
                }
            } catch (Exception ex){
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    /** Item hiển thị khách hàng */
    private static class CustomerItem {
        final Integer id;
        final String name;
        CustomerItem(Integer id, String name){ this.id=id; this.name=name; }
        @Override public String toString(){ return name; }
    }
}
