
package vn.edu.khoa.grocery.dao;
import vn.edu.khoa.grocery.config.DB; import vn.edu.khoa.grocery.model.Supplier; import java.sql.*; import java.util.*;
public class SupplierDAO implements CrudDAO<Supplier,Integer>{
  public Integer insert(Supplier s) throws Exception {
    String sql="INSERT INTO suppliers(name,phone,address) VALUES(?,?,?)";
    try(Connection c=DB.getConnection(); PreparedStatement ps=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){
      ps.setString(1,s.getName()); ps.setString(2,s.getPhone()); ps.setString(3,s.getAddress()); ps.executeUpdate();
      try(ResultSet rs=ps.getGeneratedKeys()){ if(rs.next()) return rs.getInt(1); }
    }
    return null;
  }
  public boolean update(Supplier s) throws Exception {
    String sql="UPDATE suppliers SET name=?, phone=?, address=? WHERE id=?";
    try(Connection c=DB.getConnection(); PreparedStatement ps=c.prepareStatement(sql)){
      ps.setString(1,s.getName()); ps.setString(2,s.getPhone()); ps.setString(3,s.getAddress()); ps.setInt(4,s.getId());
      return ps.executeUpdate()>0;
    }
  }
  public boolean delete(Integer id) throws Exception {
    try(Connection c=DB.getConnection(); PreparedStatement ps=c.prepareStatement("DELETE FROM suppliers WHERE id=?")){
      ps.setInt(1,id); return ps.executeUpdate()>0;
    }
  }
  public Optional<Supplier> findById(Integer id) throws Exception {
    try(Connection c=DB.getConnection(); PreparedStatement ps=c.prepareStatement("SELECT * FROM suppliers WHERE id=?")){
      ps.setInt(1,id); try(ResultSet rs=ps.executeQuery()){ if(rs.next()) return Optional.of(map(rs)); }
    }
    return Optional.empty();
  }
  public List<Supplier> findAll() throws Exception {
    List<Supplier> list=new ArrayList<>();
    try(Connection c=DB.getConnection(); Statement st=c.createStatement(); ResultSet rs=st.executeQuery("SELECT * FROM suppliers ORDER BY id DESC")){
      while(rs.next()) list.add(map(rs));
    }
    return list;
  }
  private Supplier map(ResultSet rs) throws SQLException {
    return new Supplier(rs.getInt("id"), rs.getString("name"), rs.getString("phone"), rs.getString("address"));
  }
}
