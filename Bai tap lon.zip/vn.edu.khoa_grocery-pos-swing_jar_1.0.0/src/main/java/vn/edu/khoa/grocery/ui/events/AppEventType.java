package vn.edu.khoa.grocery.ui.events;

/**
 * Các loại sự kiện trong hệ thống
 * Khi dữ liệu thay đổi ở Panel này, publish sự kiện tương ứng
 * Panel khác subscribe sự kiện đó để tự reload()
 */
public enum AppEventType {
    CATEGORY_CHANGED,
    PRODUCT_CHANGED,
    SUPPLIER_CHANGED,
    CUSTOMER_CHANGED,
    PURCHASE_CHANGED,
    SALE_CHANGED,
    USER_CHANGED
}
