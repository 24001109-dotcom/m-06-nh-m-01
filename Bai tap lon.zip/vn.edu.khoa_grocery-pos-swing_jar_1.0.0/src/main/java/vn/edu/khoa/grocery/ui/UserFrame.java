package vn.edu.khoa.grocery.ui;

import vn.edu.khoa.grocery.config.DB;
import vn.edu.khoa.grocery.dao.ProductDAO;
import vn.edu.khoa.grocery.ui.components.InvoiceDialog;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.*;
import java.util.Vector;

public class UserFrame extends JFrame {

    private final int customerId;
    private final String customerName;

    private final DefaultTableModel productModel = new DefaultTableModel(
            new Object[]{"ID", "Tên SP", "Giá bán", "Tồn kho"}, 0
    ) { @Override public boolean isCellEditable(int r, int c){ return false; } };

    private final DefaultTableModel cartModel = new DefaultTableModel(
            new Object[]{"Tên SP", "Số lượng", "Giá", "Thành tiền"}, 0
    ) { @Override public boolean isCellEditable(int r, int c){ return false; } };

    private final JTable tblProducts = new JTable(productModel);
    private final JTable tblCart = new JTable(cartModel);

    public UserFrame(int customerId, String customerName) {
        super("Khách hàng: " + customerName);
        this.customerId = customerId;
        this.customerName = customerName;

        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Danh sách sản phẩm", buildProductPanel());
        tabs.addTab("Giỏ hàng", buildCartPanel());

        add(tabs, BorderLayout.CENTER);

        reloadProducts();
    }

    private JPanel buildProductPanel() {
        JPanel p = new JPanel(new BorderLayout(10, 10));

        tblProducts.setRowHeight(24);
        p.add(new JScrollPane(tblProducts), BorderLayout.CENTER);

        JButton btnAdd = new JButton("Thêm vào giỏ");
        btnAdd.addActionListener(e -> addToCart());

        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        south.add(btnAdd);
        p.add(south, BorderLayout.SOUTH);

        return p;
    }

    private JPanel buildCartPanel() {
        JPanel p = new JPanel(new BorderLayout(10, 10));

        tblCart.setRowHeight(24);
        p.add(new JScrollPane(tblCart), BorderLayout.CENTER);

        JButton btnCheckout = new JButton("Thanh toán");
        btnCheckout.addActionListener(e -> checkout());

        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        south.add(btnCheckout);
        p.add(south, BorderLayout.SOUTH);

        return p;
    }

    private void reloadProducts() {
        productModel.setRowCount(0);
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT id, name, sale_price, stock FROM products ORDER BY id");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                productModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getBigDecimal("sale_price"),
                        rs.getInt("stock")
                });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addToCart() {
        int row = tblProducts.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Chọn sản phẩm trước");
            return;
        }

        int productId = (int) productModel.getValueAt(row, 0);
        String name = (String) productModel.getValueAt(row, 1);
        BigDecimal price = (BigDecimal) productModel.getValueAt(row, 2);
        int stock = (int) productModel.getValueAt(row, 3);

        String sQty = JOptionPane.showInputDialog(this, "Nhập số lượng:", "1");
        if (sQty == null) return;

        int qty;
        try { qty = Integer.parseInt(sQty); }
        catch (Exception e) { JOptionPane.showMessageDialog(this, "Số lượng không hợp lệ"); return; }

        if (qty <= 0 || qty > stock) {
            JOptionPane.showMessageDialog(this, "Số lượng không hợp lệ hoặc vượt tồn kho");
            return;
        }

        BigDecimal total = price.multiply(BigDecimal.valueOf(qty));
        cartModel.addRow(new Object[]{ name, qty, price, total });
    }

    private void checkout() {
        if (cartModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Giỏ hàng trống");
            return;
        }

        try (Connection c = DB.getConnection()) {
            c.setAutoCommit(false);

            BigDecimal total = BigDecimal.ZERO;
            for (int i=0; i<cartModel.getRowCount(); i++) {
                total = total.add((BigDecimal) cartModel.getValueAt(i, 3));
            }

            // 1. Tạo đơn hàng
            int orderId;
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO sales_orders(customer_id, order_date, total) VALUES (?,?,?)",
                    Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, customerId);
                ps.setDate(2, new java.sql.Date(System.currentTimeMillis()));
                ps.setBigDecimal(3, total);
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) { rs.next(); orderId = rs.getInt(1); }
            }

            // 2. Thêm chi tiết giỏ hàng
            for (int i=0; i<cartModel.getRowCount(); i++) {
                String name = (String) cartModel.getValueAt(i, 0);
                int qty = (int) cartModel.getValueAt(i, 1);
                BigDecimal price = (BigDecimal) cartModel.getValueAt(i, 2);

                int productId = ProductDAO.findProductIdByName(name, c);

                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO sales_items(order_id, product_id, qty, price) VALUES (?,?,?,?)")) {
                    ps.setInt(1, orderId);
                    ps.setInt(2, productId);
                    ps.setInt(3, qty);
                    ps.setBigDecimal(4, price);
                    ps.executeUpdate();
                }
            }

            c.commit();

            // 3. Hiện hóa đơn
            Vector<Vector<Object>> rows = new Vector<>();
            for (int i=0; i<cartModel.getRowCount(); i++) {
                Vector<Object> r = new Vector<>();
                r.add(cartModel.getValueAt(i, 0));
                r.add(cartModel.getValueAt(i, 1));
                r.add(cartModel.getValueAt(i, 2));
                r.add(cartModel.getValueAt(i, 3));
                rows.add(r);
            }
            new InvoiceDialog(this, orderId, customerName, rows, total).setVisible(true);

            cartModel.setRowCount(0);
            reloadProducts();

            JOptionPane.showMessageDialog(this, "Thanh toán thành công!");

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }
}
