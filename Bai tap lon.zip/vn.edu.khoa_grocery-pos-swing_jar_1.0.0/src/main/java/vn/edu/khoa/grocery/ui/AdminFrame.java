package vn.edu.khoa.grocery.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

import vn.edu.khoa.grocery.ui.panels.ProductPanel;
import vn.edu.khoa.grocery.ui.panels.CategoryPanel;
import vn.edu.khoa.grocery.ui.panels.SupplierPanel;
import vn.edu.khoa.grocery.ui.panels.CustomerPanel;
import vn.edu.khoa.grocery.ui.panels.PurchasePanel;
import vn.edu.khoa.grocery.ui.panels.OrdersPanel;

public class AdminFrame extends JFrame {

    private final String username;

    /** Constructor đầy đủ theo yêu cầu trước đây */
    public AdminFrame(String username) {
        super("Quản trị hệ thống - " + (username == null ? "" : username));
        this.username = username;
        initUI();
    }

    /** Constructor mặc định để tránh lỗi khi nơi khác gọi new AdminFrame() */
    public AdminFrame() {
        this("Admin");
    }

    private void initUI() {
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1100, 720);
        setLocationRelativeTo(null);

        // ====== Menu: Tài khoản -> Đăng xuất ======
        setJMenuBar(buildMenuBar());

        // ====== Tabs chính ======
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Sản phẩm", new ProductPanel());
        tabs.addTab("Danh mục", new CategoryPanel());
        tabs.addTab("Nhà cung cấp", new SupplierPanel());
        tabs.addTab("Khách hàng", new CustomerPanel());
        tabs.addTab("Nhập hàng", new PurchasePanel());
        tabs.addTab("Đơn hàng", new OrdersPanel());
        // Nếu bạn có quản lý người dùng thì bật dòng sau
        // tabs.addTab("Người dùng", new UserPanel());

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(tabs, BorderLayout.CENTER);
    }

    private JMenuBar buildMenuBar() {
        JMenuBar bar = new JMenuBar();

        JMenu account = new JMenu("Tài khoản");
        account.setMnemonic(KeyEvent.VK_T);

        JMenuItem miLogout = new JMenuItem("Đăng xuất");
        miLogout.setMnemonic(KeyEvent.VK_D);
        miLogout.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L,
                Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx())); // Ctrl+L / Cmd+L
        miLogout.addActionListener(e -> doLogout());

        account.add(miLogout);
        bar.add(account);
        return bar;
    }

    private void doLogout() {
        int opt = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc muốn đăng xuất?",
                "Xác nhận",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (opt == JOptionPane.YES_OPTION) {
            // Mở lại màn hình đăng nhập, đóng admin
            SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
            dispose();
        }
    }
}
