
package vn.edu.khoa.grocery.dao;
import vn.edu.khoa.grocery.config.DB; import vn.edu.khoa.grocery.model.Category; import java.sql.*; import java.util.*;
public class CategoryDAO implements CrudDAO<Category,Integer>{
  public Integer insert(Category c0) throws Exception {
    String sql="INSERT INTO categories(name) VALUES(?)";
    try(Connection c=DB.getConnection(); PreparedStatement ps=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){
      ps.setString(1,c0.getName()); ps.executeUpdate();
      try(ResultSet rs=ps.getGeneratedKeys()){ if(rs.next()) return rs.getInt(1); }
    }
    return null;
  }
  public boolean update(Category c0) throws Exception {
    String sql="UPDATE categories SET name=? WHERE id=?";
    try(Connection c=DB.getConnection(); PreparedStatement ps=c.prepareStatement(sql)){
      ps.setString(1,c0.getName()); ps.setInt(2,c0.getId()); return ps.executeUpdate()>0;
    }
  }
  public boolean delete(Integer id) throws Exception {
    try(Connection c=DB.getConnection(); PreparedStatement ps=c.prepareStatement("DELETE FROM categories WHERE id=?")){
      ps.setInt(1,id); return ps.executeUpdate()>0;
    }
  }
  public Optional<Category> findById(Integer id) throws Exception {
    try(Connection c=DB.getConnection(); PreparedStatement ps=c.prepareStatement("SELECT * FROM categories WHERE id=?")){
      ps.setInt(1,id); try(ResultSet rs=ps.executeQuery()){ if(rs.next()) return Optional.of(map(rs)); }
    }
    return Optional.empty();
  }
  public List<Category> findAll() throws Exception {
    List<Category> list=new ArrayList<>();
    try(Connection c=DB.getConnection(); Statement st=c.createStatement(); ResultSet rs=st.executeQuery("SELECT * FROM categories ORDER BY name")){
      while(rs.next()) list.add(map(rs));
    }
    return list;
  }
  private Category map(ResultSet rs) throws SQLException { return new Category(rs.getInt("id"), rs.getString("name")); }
}
