
package vn.edu.khoa.grocery.ui;
import com.formdev.flatlaf.FlatLightLaf; import vn.edu.khoa.grocery.ui.panels.*; import javax.swing.*;
public class MainFrame extends JFrame {
  public MainFrame(){ super("Grocery POS – Xuất/Nhập hàng hóa"); FlatLightLaf.setup(); setDefaultCloseOperation(EXIT_ON_CLOSE); setSize(1200,780); setLocationRelativeTo(null);
    JTabbedPane tabs=new JTabbedPane();
    tabs.addTab("Tổng quan", new DashboardPanel());
    tabs.addTab("Sản phẩm", new ProductPanel());
    tabs.addTab("Danh mục", new CategoryPanel());
    tabs.addTab("Nhà cung cấp", new SupplierPanel());
    tabs.addTab("Khách hàng", new CustomerPanel());
    tabs.addTab("Nhập hàng", new PurchasePanel());
tabs.addTab("Người dùng", new UserPanel());
tabs.addTab("Đơn hàng", new OrdersPanel());
    setContentPane(tabs);
  }
}
