package vn.edu.khoa.grocery.dao;

import vn.edu.khoa.grocery.config.DB;
import vn.edu.khoa.grocery.model.User;
import org.mindrot.jbcrypt.BCrypt;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO cho bảng users.
 * - Đăng nhập: UserDAO.findByUsername(...) (static) — tự dò cột mật khẩu (password_hash / pass_hash / password)
 * - Quản trị: findAll(), insert(User), setPassword(id, newPass), delete(id) — instance methods dùng cho UserPanel
 */
public class UserDAO {

    /* =======================
     *  ĐĂNG NHẬP (STATIC)
     * ======================= */
    public static User findByUsername(String username) throws Exception {
        try (Connection c = DB.getConnection()) {
            String passCol = detectPassColumn(c); // password_hash -> pass_hash -> password
            String sql = "SELECT id, username, full_name, role, " + passCol + " AS pass " +
                         "FROM users WHERE username=? LIMIT 1";
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setString(1, username);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        User u = new User();
                        u.setId(rs.getInt("id"));
                        u.setUsername(t(rs.getString("username")));
                        u.setFullName(t(rs.getString("full_name")));
                        u.setRole(t(rs.getString("role")));
                        u.setPasswordHash(t(rs.getString("pass"))); // chính là giá trị thật đang lưu
                        return u;
                    }
                }
            }
        }
        return null;
    }

    /* Tự phát hiện cột mật khẩu đang có trong bảng users */
    private static String detectPassColumn(Connection c) throws SQLException {
        String sql =
            "SELECT COLUMN_NAME " +
            "FROM INFORMATION_SCHEMA.COLUMNS " +
            "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='users' " +
            "AND COLUMN_NAME IN ('password_hash','pass_hash','password') " +
            "ORDER BY FIELD(COLUMN_NAME,'password_hash','pass_hash','password') " +
            "LIMIT 1";
        try (PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getString(1);
        }
        return "password_hash"; // fallback an toàn
    }

    private static String t(String s){ return s == null ? null : s.trim(); }

    /* =======================
     *  QUẢN TRỊ (INSTANCE)
     * ======================= */

    /** Lấy tất cả users (cho UserPanel) */
    public List<User> findAll() throws Exception {
        List<User> list = new ArrayList<>();
        try (Connection c = DB.getConnection()) {
            // Dò cột mật khẩu để đọc cho thống nhất (dù bảng có cột nào)
            String passCol = detectPassColumn(c);
            String sql = "SELECT id, username, full_name, role, " + passCol + " AS pass " +
                         "FROM users ORDER BY id DESC";
            try (PreparedStatement ps = c.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    User u = new User();
                    u.setId(rs.getInt("id"));
                    u.setUsername(t(rs.getString("username")));
                    u.setFullName(t(rs.getString("full_name")));
                    u.setRole(t(rs.getString("role")));
                    u.setPasswordHash(t(rs.getString("pass")));
                    list.add(u);
                }
            }
        }
        return list;
    }

    /** Thêm mới user (mật khẩu ở u.getPasswordHash() là mật khẩu gốc; DAO sẽ hash BCrypt trước khi lưu) */
    public boolean insert(User u) throws Exception {
        if (u == null) return false;
        String fullName = u.getFullName() == null ? "" : u.getFullName();
        String role = (u.getRole() == null || u.getRole().isBlank()) ? "STAFF" : u.getRole();

        // luôn lưu vào cột password_hash (nên chuẩn hoá DB dùng cột này)
        String sql = "INSERT INTO users(username, password_hash, full_name, role) VALUES(?,?,?,?)";
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, u.getUsername());
            ps.setString(2, BCrypt.hashpw(u.getPasswordHash(), BCrypt.gensalt())); // hash
            ps.setString(3, fullName);
            ps.setString(4, role);
            return ps.executeUpdate() > 0;
        }
    }

    /** Đặt lại mật khẩu (hash BCrypt) */
    public boolean setPassword(int id, String newPass) throws Exception {
        String sql = "UPDATE users SET password_hash=? WHERE id=?";
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, BCrypt.hashpw(newPass, BCrypt.gensalt())); // hash
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        }
    }

    /** Xoá user */
    public boolean delete(int id) throws Exception {
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM users WHERE id=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }
}
