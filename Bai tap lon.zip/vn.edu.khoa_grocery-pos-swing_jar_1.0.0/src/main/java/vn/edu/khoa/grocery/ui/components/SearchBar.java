
package vn.edu.khoa.grocery.ui.components;
import javax.swing.*; import java.awt.event.*; import java.util.function.Consumer;
public class SearchBar extends JPanel {
  private final JTextField text = new JTextField(20);
  public SearchBar(String placeholder, Consumer<String> onChange) {
    setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
    add(new JLabel("Tìm kiếm:")); add(text);
    text.addKeyListener(new KeyAdapter(){ @Override public void keyReleased(KeyEvent e){ onChange.accept(text.getText().trim()); } });
  }
}
