package vn.edu.khoa.grocery.dao;

import vn.edu.khoa.grocery.config.DB;
import vn.edu.khoa.grocery.model.PurchaseOrder;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PurchaseOrderDAO implements CrudDAO<PurchaseOrder, Integer> {

    @Override
    public Integer insert(PurchaseOrder o) throws Exception {
        String sql = "INSERT INTO purchase_orders(supplier_id, order_date, total) VALUES(?,?,?)";
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, o.getSupplierId());
            ps.setDate(2, Date.valueOf(o.getOrderDate())); // LocalDate -> DATE
            ps.setDouble(3, o.getTotal());                 // dùng double theo model hiện tại
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return null;
    }

    @Override
    public boolean update(PurchaseOrder o) throws Exception {
        String sql = "UPDATE purchase_orders SET supplier_id=?, order_date=?, total=? WHERE id=?";
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, o.getSupplierId());
            ps.setDate(2, Date.valueOf(o.getOrderDate()));
            ps.setDouble(3, o.getTotal()); // double
            ps.setInt(4, o.getId());
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean delete(Integer id) throws Exception {
        try (Connection c = DB.getConnection()) {
            c.setAutoCommit(false);
            // Xoá items trước để không dính khoá ngoại (nếu DB chưa ON DELETE CASCADE)
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM purchase_items WHERE order_id=?")) {
                ps.setInt(1, id);
                ps.executeUpdate();
            }
            int affected;
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM purchase_orders WHERE id=?")) {
                ps.setInt(1, id);
                affected = ps.executeUpdate();
            }
            c.commit();
            return affected > 0;
        }
    }

    @Override
    public Optional<PurchaseOrder> findById(Integer id) throws Exception {
        String sql = "SELECT id, supplier_id, order_date, total FROM purchase_orders WHERE id=?";
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(map(rs));
            }
        }
        return Optional.empty();
    }

    @Override
    public List<PurchaseOrder> findAll() throws Exception {
        List<PurchaseOrder> list = new ArrayList<>();
        String sql = "SELECT id, supplier_id, order_date, total FROM purchase_orders ORDER BY id DESC";
        try (Connection c = DB.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    /** Dùng cho UI: lấy kèm tên NCC */
    public List<RowWithSupplierName> findAllWithSupplierName() throws Exception {
        List<RowWithSupplierName> list = new ArrayList<>();
        String sql = """
                SELECT po.id, po.order_date, po.total, s.name AS supplier_name, po.supplier_id
                FROM purchase_orders po
                JOIN suppliers s ON s.id = po.supplier_id
                ORDER BY po.id DESC
                """;
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new RowWithSupplierName(
                        rs.getInt("id"),
                        rs.getInt("supplier_id"),
                        rs.getString("supplier_name"),
                        rs.getDate("order_date").toLocalDate(),
                        rs.getDouble("total")
                ));
            }
        }
        return list;
    }

    private PurchaseOrder map(ResultSet rs) throws SQLException {
        int id = rs.getInt("id");
        int supplierId = rs.getInt("supplier_id");
        LocalDate date = rs.getDate("order_date").toLocalDate();
        double total = rs.getDouble("total");    // double theo model
        return new PurchaseOrder(id, supplierId, date, total);
    }

    /** DTO gọn cho UI */
    public static class RowWithSupplierName {
        public final int id;
        public final int supplierId;
        public final String supplierName;
        public final LocalDate orderDate;
        public final double total;

        public RowWithSupplierName(int id, int supplierId, String supplierName, LocalDate orderDate, double total) {
            this.id = id;
            this.supplierId = supplierId;
            this.supplierName = supplierName;
            this.orderDate = orderDate;
            this.total = total;
        }
    }
}
