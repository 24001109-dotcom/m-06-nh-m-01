
package vn.edu.khoa.grocery.ui.panels;
import vn.edu.khoa.grocery.config.DB; 
import vn.edu.khoa.grocery.ui.events.*;
import javax.swing.*; import java.awt.*; import java.sql.*;
public class DashboardPanel extends JPanel{
  private final JLabel lblRevenue=new JLabel("0"), lblStock=new JLabel("0");
  public DashboardPanel(){ 
    setLayout(new GridLayout(1,2,16,16)); 
    add(card("Doanh thu hôm nay",lblRevenue)); 
    add(card("Tổng tồn kho",lblStock)); 
    // subscribe events để tự làm mới
    AppEventBus.get().subscribe(AppEventType.PRODUCT_CHANGED, this::reload);
    AppEventBus.get().subscribe(AppEventType.SALE_CHANGED, this::reload);
    AppEventBus.get().subscribe(AppEventType.PURCHASE_CHANGED, this::reload);
    reload(); 
  }
  private JPanel card(String title, JComponent value){ JPanel p=new JPanel(new BorderLayout()); p.setBorder(BorderFactory.createTitledBorder(title)); JLabel big=(value instanceof JLabel)?(JLabel)value:new JLabel("?"); big.setFont(big.getFont().deriveFont(Font.BOLD,28f)); big.setHorizontalAlignment(SwingConstants.CENTER); p.add(big,BorderLayout.CENTER); return p; }
  private void reload(){ try(Connection c=DB.getConnection(); Statement st=c.createStatement()){
      try(ResultSet rs=st.executeQuery("SELECT COALESCE(SUM(total),0) FROM sales_orders WHERE order_date=CURRENT_DATE")){ if(rs.next()) lblRevenue.setText(String.format("%,.0f",rs.getDouble(1))); }
      try(ResultSet rs=st.executeQuery("SELECT COALESCE(SUM(stock),0) FROM products")){ if(rs.next()) lblStock.setText(String.valueOf(rs.getInt(1))); }
    } catch(Exception e){}
  }
}
