
# Grocery POS (Swing + XAMPP MySQL)

## Cách chạy
1. Mở XAMPP → Start **Apache** & **MySQL**.
2. Vào phpMyAdmin → chạy `src/main/resources/schema.sql`.
3. Chạy NetBeans 22 (JDK 22) hoặc:
```
mvn -q -Dexec.mainClass=vn.edu.khoa.grocery.AppMain exec:java
```
Đăng nhập: `admin / Admin@123`.
